package com.cts.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cts.entity.Client;
import com.cts.service.ClientService;

@RestController
@RequestMapping("/client")
public class ClientController {

	@Autowired
	ClientService clientService;

	@RequestMapping("/")
	public String defaultCase() {
		return "i am default";
	}

	// @RequestMapping(value = "/list", method = RequestMethod.GET)
	// public ResponseEntity<List<Client>> getClients() {
	// List<Client> list = clientService.listAllClients();
	// HttpHeaders responseHeaders = new HttpHeaders();
	// responseHeaders.set("Access-Control-Allow-Origin", "*");
	// return new ResponseEntity<List<Client>>(list, responseHeaders,
	// HttpStatus.OK);
	// }

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ResponseEntity<HashMap<String, Object>> getTestClients() {
		List<Client> list = clientService.listAllClients();
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set("Access-Control-Allow-Origin", "*");
		HashMap<String, Object> map = new HashMap<>();
		if (list.size() < 0 || list.isEmpty()) {
			map.put("status", "400");
			map.put("message", "No Records Available");
			map.put("results", list);
		} else {
			map.put("status", "200");
			map.put("results", list);
		}
		return new ResponseEntity<HashMap<String, Object>>(map, responseHeaders, HttpStatus.OK);

	}

	// @RequestMapping("/test")
	// public HashMap<String, Object> get() {
	// HashMap<String, Object> map = new HashMap<>();
	// map.put("status", "200");
	// map.put("results", "kirti");
	// return map;
	// }
}
