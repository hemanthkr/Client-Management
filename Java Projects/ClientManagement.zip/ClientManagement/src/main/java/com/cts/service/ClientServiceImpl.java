/**
 * 
 */
package com.cts.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.ClientDAO;
import com.cts.entity.Client;

/**
 * @author 758154
 *
 */
@Service("clientService")
public class ClientServiceImpl implements ClientService {

	@Autowired
	ClientDAO clientDAO;

	@Override
	@Transactional
	public List<Client> listAllClients() {
		List<Client> list = clientDAO.getAllClientList();
		return list;
	}

}
