package com.cts.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name = "client")
@DynamicUpdate
public class Client {

	@Id
	@Column(name = "cl_id")
	int id;
	@Column(name = "cl_name")
	String name;
	@Column(name = "cl_project_name")
	String projectName;
	@Column(name = "cl_budget")
	String budget;
	@Column(name = "cl_location")
	String location;
	@Column(name = "cl_email")
	String email;
	@Column(name = "cl_address")
	String address;
	@Column(name = "cl_contact")
	String contact;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getBudget() {
		return budget;
	}

	public void setBudget(String budget) {
		this.budget = budget;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Client(int id, String name, String projectName, String budget, String location, String email, String address,
			String contact) {
		super();
		this.id = id;
		this.name = name;
		this.projectName = projectName;
		this.budget = budget;
		this.location = location;
		this.email = email;
		this.address = address;
		this.contact = contact;
	}

	public Client() {
		super();
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", projectName=" + projectName + ", budget=" + budget
				+ ", location=" + location + ", email=" + email + ", address=" + address + ", contact=" + contact + "]";
	}

}
