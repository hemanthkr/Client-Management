/**
 * 
 */
package com.cts.service;

import java.util.List;

import com.cts.entity.Client;

/**
 * @author 758154
 *
 */
public interface ClientService {
	public List<Client> listAllClients();
}
