/**
 * 
 */
package com.cts.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.entity.Client;

/**
 * @author 758154
 *
 */
@Repository("clientDAO")
public class ClientDAOImpl implements ClientDAO {

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public List<Client> getAllClientList() {
		List<Client> clientsList = new ArrayList<>();
		Session session = sessionFactory.getCurrentSession();
		CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
		CriteriaQuery<Client> criteriaQuery = criteriaBuilder.createQuery(Client.class);
		Root<Client> root = criteriaQuery.from(Client.class);
		criteriaQuery.select(root);
		Query query = session.createQuery(criteriaQuery);
		clientsList = query.getResultList();
		return clientsList;
	}

}
