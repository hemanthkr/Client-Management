package com.cts.dao;

import java.util.List;

import com.cts.entity.Client;

public interface ClientDAO {
	public List<Client> getAllClientList();
}
