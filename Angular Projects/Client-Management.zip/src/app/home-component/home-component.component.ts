import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Client } from '../shared/client/client';
import { ControllerService } from '../shared/service/controller.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home-component',
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.css']
})
export class HomeComponentComponent implements OnInit {

  protected Client: Observable<Client[]>;

  constructor(public controller: ControllerService, protected router: Router) { }

  ngOnInit() {
    this.controller.getClients().subscribe(res => {
      this.Client = res;
    });
  }



}
