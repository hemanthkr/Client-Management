import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatToolbarModule, MatDividerModule } from '@angular/material';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MatToolbarModule,
    MatDividerModule,
    BrowserAnimationsModule
  ],
  exports: [
    MatToolbarModule,
    MatDividerModule,
    BrowserAnimationsModule
  ]
})
export class MatModule { }
