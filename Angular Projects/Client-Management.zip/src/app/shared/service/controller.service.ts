import { Injectable } from '@angular/core';
import { Client } from '../client/client';

import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ControllerService {

  constructor(private http: HttpClient) { }

  protected url = 'http://localhost:8080/empl/client/';

  protected client_list ="list";
  
  getClients(): Observable<any> {
    return this.http.get(this.url+this.client_list).pipe(map(res => res));
  }

 
}
