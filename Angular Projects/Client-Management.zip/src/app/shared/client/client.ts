export interface Client {
    id: number;
    name: string;
    location: string;
    email: string;
    contact: string;
}
