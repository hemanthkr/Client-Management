import { Component, OnInit } from '@angular/core';
import { UserService } from '../shared/user.service';
import { Observable } from 'rxjs';
import { IUser } from '../shared/iuser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  protected Users: Observable<IUser[]>;

  constructor(public userservice: UserService, protected router: Router) { }

  ngOnInit() {
    this.userservice.getUsers().subscribe(res => {
      this.Users = res;
    });
  }

  saveName(username) {
    sessionStorage.setItem('user', JSON.stringify(username));
    this.router.navigateByUrl('/user-detail');
  }

}
